package com.example.yuri

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(Color.BLACK)
        }

        val title = TextView(this).apply {
            text = "YURI"
            textSize = 54f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = "Premi per sentirlo di nuovo"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 28)
        }

        val button = Button(this).apply {
            text = "RIPETI YURI!"
            textSize = 18f
            setOnClickListener { sayYuri() }
        }

        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(button)
        setContentView(layout)

        tts = TextToSpeech(this, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val languageResult = tts?.setLanguage(Locale.ITALIAN)
            tts?.setPitch(0.65f)       // Più grave: dipende dalla voce installata
            tts?.setSpeechRate(0.85f)  // Leggermente più lento e solenne
            ttsReady = languageResult != TextToSpeech.LANG_MISSING_DATA &&
                       languageResult != TextToSpeech.LANG_NOT_SUPPORTED

            if (ttsReady) {
                // Piccola pausa per rendere l'annuncio più naturale.
                window.decorView.postDelayed({ sayYuri() }, 250)
            }
        }
    }

    private fun sayYuri() {
        if (ttsReady) {
            tts?.speak("Yuriiii!", TextToSpeech.QUEUE_FLUSH, null, "yuri_intro")
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }
}
