YURI - app Android

Questa app pronuncia "Yuriiii!" quando viene aperta e include un pulsante per ripetere.
Usa la sintesi vocale Android: il timbro dipende dalla voce installata sul telefono.

COME OTTENERE L'APK SENZA INSTALLARE ANDROID STUDIO
Il progetto include una compilazione automatica tramite GitHub Actions.

1. Dal PC o dal telefono, apri github.com e accedi/crea un account gratuito.
2. Crea un nuovo repository (New repository), chiamalo YURI e impostalo come Public o Private.
3. Estrai questo ZIP e carica TUTTI i file e le cartelle contenuti nella cartella YURI-Android nel repository. Includi anche la cartella nascosta .github.
   Se carichi dal browser del telefono e non vedi .github, usa un PC oppure crea il workflow manualmente su GitHub nel percorso .github/workflows/build-apk.yml.
4. Dopo il caricamento, apri la scheda Actions del repository.
5. Seleziona "Build YURI APK" e, se necessario, premi "Run workflow".
6. Quando il processo è verde/completato, apri la sua esecuzione e scarica l'artefatto "YURI-apk".
7. Estrai l'artefatto ZIP: troverai app-debug.apk. Aprilo sul telefono e autorizza l'installazione da quella fonte se Android lo richiede.

NOTA
Non è ancora un APK già compilato: questo progetto fa compilare gratuitamente l'APK dai server GitHub.
Non richiede permessi speciali né connessione internet per pronunciare la frase dopo l'installazione,
ma la disponibilità della voce italiana dipende dalle voci TTS presenti sul dispositivo.
